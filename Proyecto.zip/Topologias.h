#ifndef TOPOLOGIAS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void crear_top(int link,const char *topologia,const char *texto);
#endif